package com.example.ac1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class BookActivity extends AppCompatActivity {
    EditText edtTitle, edtAuthor;
    Spinner spnCategory;
    CheckBox chkRead;
    Button btnSave;
    ListView listViewBooks;
    BancoHelper databaseHelper;
    ArrayAdapter<String> adapter;
    ArrayList<String> bookList;
    ArrayList<Integer> bookIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        edtTitle = findViewById(R.id.edtTitle);
        edtAuthor = findViewById(R.id.edtAuthor);
        spnCategory = findViewById(R.id.spnCategory);
        chkRead = findViewById(R.id.chkRead);
        btnSave = findViewById(R.id.btnSave);
        listViewBooks = findViewById(R.id.listViewBooks);
        databaseHelper = new BancoHelper(this);

        edtTitle.setHint(R.string.title_hint);
        edtAuthor.setHint(R.string.author_hint);
        chkRead.setText(R.string.read_status);
        btnSave.setText(R.string.save_button);


        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.book_categories,
                android.R.layout.simple_spinner_item
        );
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCategory.setAdapter(categoryAdapter);

        // Load books when activity starts
        loadBooks();

        btnSave.setOnClickListener(v -> {
            String title = edtTitle.getText().toString();
            String author = edtAuthor.getText().toString();
            String category = spnCategory.getSelectedItem().toString();
            boolean isRead = chkRead.isChecked();

            if (!title.isEmpty() && !author.isEmpty()) {
                long result = databaseHelper.insertBook(title, author, category, isRead);
                if (result != -1) {
                    Toast.makeText(this, R.string.book_saved, Toast.LENGTH_SHORT).show();
                    clearFields();
                    loadBooks();
                } else {
                    Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, R.string.required_fields, Toast.LENGTH_SHORT).show();
            }
        });

        listViewBooks.setOnItemClickListener((parent, view, position, id) -> {
            int bookId = bookIds.get(position);
            String[] bookDetails = bookList.get(position).split(" - ");

            edtTitle.setText(bookDetails[1]); // Title
            edtAuthor.setText(bookDetails[2]); // Author

            // Set category spinner
            String category = bookDetails[3];
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this, R.array.book_categories, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spnCategory.setAdapter(adapter);
            int spinnerPosition = adapter.getPosition(category);
            spnCategory.setSelection(spinnerPosition);

            // Set read status
            boolean isRead = bookDetails[4].equals("Read");
            chkRead.setChecked(isRead);

            btnSave.setText("Update");

            btnSave.setOnClickListener(v -> {
                String title = edtTitle.getText().toString();
                String author = edtAuthor.getText().toString();
                String categoryUpdate = spnCategory.getSelectedItem().toString();
                boolean isReadUpdate = chkRead.isChecked();

                if (!title.isEmpty() && !author.isEmpty()) {
                    int result = databaseHelper.updateBook(bookId, title, author, categoryUpdate, isReadUpdate);
                    if (result > 0) {
                        Toast.makeText(this, "Book updated!", Toast.LENGTH_SHORT).show();
                        clearFields();
                        loadBooks();
                        btnSave.setText("Save");
                    } else {
                        Toast.makeText(this, "Error updating book!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Please fill all required fields!", Toast.LENGTH_SHORT).show();
                }
            });
        });

        listViewBooks.setOnItemLongClickListener((parent, view, position, id) -> {
            int bookId = bookIds.get(position);
            int deleted = databaseHelper.deleteBook(bookId);
            if (deleted > 0) {
                Toast.makeText(this, "Book deleted!", Toast.LENGTH_SHORT).show();
                loadBooks();
            }
            return true;
        });
    }

    private void loadBooks() {
        Cursor cursor = databaseHelper.getAllBooks();
        bookList = new ArrayList<>();
        bookIds = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String author = cursor.getString(2);
                String category = cursor.getString(3);
                int isRead = cursor.getInt(4);
                String readStatus = isRead == 1 ? "Read" : "Unread";

                bookList.add(id + " - " + title + " - " + author + " - " + category + " - " + readStatus);
                bookIds.add(id);
            } while (cursor.moveToNext());
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookList);
        listViewBooks.setAdapter(adapter);
    }

    private void clearFields() {
        edtTitle.setText("");
        edtAuthor.setText("");
        chkRead.setChecked(false);
    }

    public void voltar(View view) {
        finish();
    }
}